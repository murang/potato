using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;

namespace GameLogic
{
    public class KCPStream : Stream
    {
        private Socket mSocket;
        private readonly bool mOwnsSocket;
        private readonly KCP mKCP;
        private bool mClosed;
        private readonly ByteBuffer mRecvBuffer = ByteBuffer.Allocate(1024 * 32);
        private readonly byte[] mInputBuffer = new byte[65535];
        private const int UpdateIntervalMs = 10;
        private readonly DateTime startDt = DateTime.Now;

        public bool IsConnected { get { lock (mKCP) return !mClosed && mSocket.Connected; } }
        public bool WriteDelay { get; set; }
        public bool AckNoDelay { get; set; }
        public IPEndPoint RemoteAddress { get; private set; }
        public IPEndPoint LocalAddress { get; private set; }

        public KCPStream(Socket s, bool ownsSocket)
        {
            mSocket = s ?? throw new ArgumentNullException(nameof(s));
            mOwnsSocket = ownsSocket;
            RemoteAddress = (IPEndPoint)s.RemoteEndPoint;
            LocalAddress = (IPEndPoint)s.LocalEndPoint;
            // KCP 锁内只做非阻塞 UDP I/O；等待可写/可读时必须释放锁，
            // 否则 ACK、Update 和关闭都无法推进。
            s.Blocking = false;
            mKCP = new KCP((uint)new Random().Next(1, Int32.MaxValue), RawSend);
            mKCP.NoDelay(1, UpdateIntervalMs, 2, 1);
            mKCP.SetStreamMode(true);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                Socket socket;
                lock (mKCP)
                {
                    if (mClosed) return;
                    mClosed = true;
                    socket = mSocket;
                    mSocket = null;
                    mRecvBuffer.Clear();
                }
                if (mOwnsSocket) socket.Close();
            }
            base.Dispose(disposing);
        }

        private void RawSend(byte[] data, int length)
        {
            try
            {
                mSocket.Send(data, length, SocketFlags.None);
            }
            catch (SocketException e) when (e.SocketErrorCode == SocketError.WouldBlock ||
                                           e.SocketErrorCode == SocketError.NoBufferSpaceAvailable)
            {
                // UDP 暂时发不出去时由 KCP 的未确认分片负责重传，
                // 不把应用层帧当成已确认或释放发送窗口。
            }
        }

        // 调用方持有 mKCP。每轮限制 UDP 输入量，避免持续收包独占锁。
        // 写窗口等待也运行此泵，因此即使没有业务回复，ACK 仍能解除阻塞。
        private void Pump()
        {
            for (int i = 0; i < 32 && mSocket.Poll(0, SelectMode.SelectRead); i++)
            {
                int n;
                try { n = mSocket.Receive(mInputBuffer, SocketFlags.None); }
                catch (SocketException e) when (e.SocketErrorCode == SocketError.WouldBlock) { break; }
                if (n == 0) continue; // 空 UDP 数据报不表示连接 EOF。
                if (mKCP.Input(mInputBuffer, 0, n, true, AckNoDelay) < 0)
                    throw new IOException("Invalid KCP datagram");
            }
            mKCP.Update();
        }

        // 低层非阻塞接口：返回本次实际接纳的字节数，窗口满时返回 0。
        // Stream.WriteAsync 会保留剩余内容直到全部接纳，不能忽略这个返回值。
        public int Send(byte[] data, int index, int length)
        {
            ValidateBuffer(data, index, length);
            lock (mKCP)
            {
                if (mClosed) return -1;
                Pump();
                int sent = 0;
                while (sent < length && mKCP.WaitSnd < mKCP.SndWnd && mKCP.WaitSnd < mKCP.RmtWnd)
                {
                    int n = Math.Min((int)mKCP.Mss, length - sent);
                    if (mKCP.Send(data, index + sent, n) < 0) throw new IOException("KCP send failed");
                    sent += n;
                }
                if (sent > 0 && (!WriteDelay || mKCP.WaitSnd >= mKCP.SndWnd || mKCP.WaitSnd >= mKCP.RmtWnd))
                    mKCP.Flush(false);
                return sent;
            }
        }

        // 低层非阻塞接口的 0 只表示暂无数据，ReadAsync 不把它暴露为 EOF。
        public int Recv(byte[] data, int index, int length)
        {
            ValidateBuffer(data, index, length);
            lock (mKCP)
            {
                if (mClosed) return -1;
                if (length == 0) return 0;
                Pump();
                if (mRecvBuffer.ReadableBytes == 0)
                {
                    int size = mKCP.PeekSize();
                    if (size < 0) return 0;
                    mRecvBuffer.EnsureWritableBytes(size);
                    int n = mKCP.Recv(mRecvBuffer.RawBuffer, 0, size);
                    if (n < 0) throw new IOException("KCP receive failed");
                    mRecvBuffer.WriterIndex = n;
                }
                int received = Math.Min(mRecvBuffer.ReadableBytes, length);
                Buffer.BlockCopy(mRecvBuffer.RawBuffer, mRecvBuffer.ReaderIndex, data, index, received);
                mRecvBuffer.ReaderIndex += received;
                if (mRecvBuffer.ReadableBytes == 0) mRecvBuffer.Clear();
                return received;
            }
        }

        public void Update()
        {
            lock (mKCP) { if (!mClosed) Pump(); }
        }

        public void Log(string str)
        {
            Console.WriteLine($"[{(int)(DateTime.Now - startDt).TotalMilliseconds,10}] {str}");
        }

        public override void Flush()
        {
            lock (mKCP)
            {
                if (mClosed) throw new ObjectDisposedException(nameof(KCPStream));
                Pump();
                mKCP.Flush(false);
            }
        }

        public override Task FlushAsync(CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            Flush();
            return Task.CompletedTask;
        }

        public override async Task<int> ReadAsync(byte[] buffer, int offset, int count, CancellationToken cancellationToken)
        {
            ValidateBuffer(buffer, offset, count);
            if (count == 0) return 0;
            while (true)
            {
                cancellationToken.ThrowIfCancellationRequested();
                int n = Recv(buffer, offset, count);
                if (n < 0) throw new ObjectDisposedException(nameof(KCPStream));
                if (n > 0) return n;
                await Task.Delay(UpdateIntervalMs, cancellationToken).ConfigureAwait(false);
            }
        }

        public override async Task WriteAsync(byte[] buffer, int offset, int count, CancellationToken cancellationToken)
        {
            ValidateBuffer(buffer, offset, count);
            int written = 0;
            while (written < count)
            {
                cancellationToken.ThrowIfCancellationRequested();
                int n = Send(buffer, offset + written, count - written);
                if (n < 0) throw new ObjectDisposedException(nameof(KCPStream));
                written += n;
                if (written < count)
                    await Task.Delay(UpdateIntervalMs, cancellationToken).ConfigureAwait(false);
            }
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            return ReadAsync(buffer, offset, count, CancellationToken.None).GetAwaiter().GetResult();
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            WriteAsync(buffer, offset, count, CancellationToken.None).GetAwaiter().GetResult();
        }

        private static void ValidateBuffer(byte[] buffer, int offset, int count)
        {
            if (buffer == null) throw new ArgumentNullException(nameof(buffer));
            if (offset < 0 || count < 0 || offset > buffer.Length - count) throw new ArgumentOutOfRangeException();
        }

        public override long Seek(long offset, SeekOrigin origin) { throw new NotSupportedException(); }
        public override void SetLength(long value) { throw new NotSupportedException(); }
        public override bool CanRead { get { lock (mKCP) return !mClosed; } }
        public override bool CanWrite { get { lock (mKCP) return !mClosed; } }
        public override bool CanSeek { get { return false; } }
        public override long Length { get { throw new NotSupportedException(); } }
        public override long Position { get { throw new NotSupportedException(); } set { throw new NotSupportedException(); } }
    }
}
