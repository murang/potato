using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Threading;
using Cysharp.Threading.Tasks;

namespace GameLogic
{
    public struct ConnOption
    {
        public string Domain;
        public string Host;
        public int Port;
        public ICodec Codec;
        public float ConnectTimeout;
        public float Timeout;
    }

    public interface IConn : IDisposable
    {
        void Connect();
        void Send(object message);
        void Disconnect();

        event Action<IConn, Exception> OnException;
        event Action<IConn> OnConnected;
        event Action<IConn> OnDisconnected;
        event Action<IConn, object> OnMessage;
    }

    public abstract class Conn : IConn
    {
        protected ConnOption Option;
        protected Socket _socket;
        protected Stream _stream;
        protected volatile bool _running;

        // 排队帧和 writer 当前持有的帧共同计费，窗口满时不能无限积累任务。
        // 这是示例的容量上限，不是进程内存上限；包体最多 1 MiB。
        private const int MaxPendingMessages = 128;
        private const int MaxPendingBytes = 8 * 1024 * 1024;
        private readonly object _sendGate = new object();
        private readonly Queue<byte[]> _sendQueue = new Queue<byte[]>();
        private readonly CancellationTokenSource _lifetime = new CancellationTokenSource();
        private int _pendingMessages;
        private int _pendingBytes;
        private bool _sending;
        private bool _connecting;
        private bool _closed;

        public event Action<IConn, Exception> OnException;
        public event Action<IConn> OnConnected;
        public event Action<IConn> OnDisconnected;
        public event Action<IConn, object> OnMessage;

        private TimeSpan IOTimeout { get { return TimeSpan.FromSeconds(Option.Timeout > 0 ? Option.Timeout : 30); } }

        public async void Connect()
        {
            lock (_sendGate)
            {
                if (_closed || _connecting || _running) return;
                _connecting = true;
            }
            try
            {
                if (_socket == null) throw new InvalidOperationException("Socket is null");
                Stream stream;
                if (_socket.ProtocolType == ProtocolType.Tcp)
                {
                    await _socket.ConnectAsync(Option.Host, Option.Port).AsUniTask()
                        .Timeout(TimeSpan.FromSeconds(Option.ConnectTimeout > 0 ? Option.ConnectTimeout : 5));
                    stream = new NetworkStream(_socket, true);
                }
                else if (_socket.ProtocolType == ProtocolType.Udp)
                {
                    _socket.Connect(Option.Host, Option.Port);
                    stream = new KCPStream(_socket, true);
                }
                else throw new NotSupportedException("Unsupported socket protocol");

                bool closed;
                lock (_sendGate)
                {
                    closed = _closed;
                    if (!closed)
                    {
                        _stream = stream;
                        _running = true;
                        _connecting = false;
                    }
                }
                if (closed) { stream.Close(); return; }
                OnConnected?.Invoke(this);
                ReceiveLoop().Forget();
            }
            catch (Exception e)
            {
                CloseConnection(e);
            }
        }

        public void Send(object message)
        {
            if (!_running) return;
            bool startWriter = false;
            bool full = false;
            try
            {
                byte[] pack = MsgPack.PackMsgData(Option.Codec.Encode(message));
                lock (_sendGate)
                {
                    if (!_running) return;
                    full = _pendingMessages >= MaxPendingMessages || pack.Length > MaxPendingBytes - _pendingBytes;
                    if (!full)
                    {
                        _sendQueue.Enqueue(pack);
                        _pendingMessages++;
                        _pendingBytes += pack.Length;
                        if (!_sending) { _sending = true; startWriter = true; }
                    }
                }
                if (full) CloseConnection(new IOException("Send queue capacity exceeded"));
                else if (startWriter) SendLoop().Forget();
            }
            catch (Exception e)
            {
                CloseConnection(e);
            }
        }

        private async UniTaskVoid SendLoop()
        {
            try
            {
                while (true)
                {
                    byte[] packet;
                    Stream stream;
                    lock (_sendGate)
                    {
                        if (!_running || _sendQueue.Count == 0)
                        {
                            _sending = false;
                            return;
                        }
                        packet = _sendQueue.Dequeue();
                        stream = _stream;
                    }
                    try
                    {
                        using (var deadline = CancellationTokenSource.CreateLinkedTokenSource(_lifetime.Token))
                        {
                            deadline.CancelAfter(IOTimeout);
                            // 某些 Unity/.NET Stream 不会中止已经开始的 I/O。
                            // 超时必须同时关闭流，不能只结束等待后继续发送下一帧。
                            using (deadline.Token.Register(() => CloseStream(stream)))
                            {
                                try
                                {
                                    await stream.WriteAsync(packet, 0, packet.Length, deadline.Token);
                                    await stream.FlushAsync(deadline.Token);
                                }
                                catch (Exception e)
                                {
                                    if (deadline.IsCancellationRequested && !_lifetime.IsCancellationRequested)
                                        throw new TimeoutException("Send timeout", e);
                                    throw;
                                }
                            }
                        }
                    }
                    finally
                    {
                        lock (_sendGate)
                        {
                            _pendingMessages--;
                            _pendingBytes -= packet.Length;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                CloseConnection(e);
                lock (_sendGate) _sending = false;
            }
        }

        private async UniTaskVoid ReceiveLoop()
        {
            try
            {
                while (_running)
                {
                    byte[] packet;
                    Stream stream = _stream;
                    using (var deadline = CancellationTokenSource.CreateLinkedTokenSource(_lifetime.Token))
                    {
                        deadline.CancelAfter(IOTimeout);
                        using (deadline.Token.Register(() => CloseStream(stream)))
                        {
                            try { packet = await MsgPack.ReceivePacket(stream, deadline.Token); }
                            catch (Exception e)
                            {
                                if (deadline.IsCancellationRequested && !_lifetime.IsCancellationRequested)
                                    throw new TimeoutException("Receive timeout", e);
                                throw;
                            }
                        }
                    }
                    object msg = Option.Codec.Decode(packet);
                    await UniTask.SwitchToMainThread();
                    if (_running) OnMessage?.Invoke(this, msg);
                }
            }
            catch (Exception e)
            {
                CloseConnection(e);
            }
        }

        public void Disconnect()
        {
            CloseConnection(null);
        }

        private void CloseConnection(Exception error)
        {
            bool notifyDisconnected;
            lock (_sendGate)
            {
                if (_closed) return;
                _closed = true;
                notifyDisconnected = _running;
                _running = false;
                _connecting = false;
                // 排队项由关闭路径释放；已取出的帧仍由 writer 的 finally 释放。
                while (_sendQueue.Count > 0)
                {
                    _pendingBytes -= _sendQueue.Dequeue().Length;
                    _pendingMessages--;
                }
            }
            _lifetime.Cancel();
            CloseStream(_stream);
            _socket?.Close();
            try
            {
                if (error != null) OnException?.Invoke(this, error);
            }
            finally
            {
                if (notifyDisconnected) OnDisconnected?.Invoke(this);
            }
        }

        private static void CloseStream(Stream stream)
        {
            // 清理错误不能掩盖原始读写错误，也不能阻止其余资源的释放。
            try { stream?.Close(); } catch (Exception) { }
        }

        public void Dispose()
        {
            Disconnect();
        }
    }
}
