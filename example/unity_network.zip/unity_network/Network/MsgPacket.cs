using System;
using System.IO;
using System.Threading;
using Cysharp.Threading.Tasks;

namespace GameLogic
{
    public class MsgPack
    {
        const int BodyLenSize = 4;
        const int MaxPackSize = 1024 * 1024;

        public static UniTask<byte[]> ReceivePacket(Stream stream)
        {
            return ReceivePacket(stream, CancellationToken.None);
        }

        public static async UniTask<byte[]> ReceivePacket(Stream stream, CancellationToken cancellationToken)
        {
            var lenBytes = await ReadFull(stream, BodyLenSize, cancellationToken);
            if (BitConverter.IsLittleEndian)
            {
                Array.Reverse(lenBytes);
            }
            int len = BitConverter.ToInt32(lenBytes, 0);
            // 包头是不可信输入，必须在分配包体之前拒绝负数和超长包。
            if (len < 0 || len > MaxPackSize)
            {
                throw new InvalidDataException("Invalid packet length: " + len);
            }

            var msgBytes = await ReadFull(stream, len, cancellationToken);
            return msgBytes;
        }

        public static byte[] PackMsgData(byte[] msgData)
        {
            if (msgData == null) throw new ArgumentNullException(nameof(msgData));
            if (msgData.Length > MaxPackSize) throw new InvalidDataException("Packet exceeds maximum length");
            byte[] packData = new byte[BodyLenSize + msgData.Length];
            var lenBytes = BitConverter.GetBytes(msgData.Length);
            if (BitConverter.IsLittleEndian)
            {
                Array.Reverse(lenBytes);
            }
            Array.Copy(lenBytes, packData, BodyLenSize);
            Array.Copy(msgData, 0, packData, BodyLenSize, msgData.Length);
            return packData;
        }

        /// <summary>
        /// 阻塞直到读满
        /// </summary>
        /// <param name="stream"></param>
        /// <param name="len"></param>
        private static async UniTask<byte[]> ReadFull(Stream stream, int len, CancellationToken cancellationToken)
        {
            int offset = 0;
            byte[] buf = new byte[len];
            while (offset < len)
            {
                int read = await stream.ReadAsync(buf, offset, len - offset, cancellationToken);
                // Stream 的 0 表示 EOF；继续循环会在断线后无休止空转。
                if (read == 0) throw new EndOfStreamException("Connection closed during packet read");
                offset += read;
            }

            return buf;
        }
    }
}
