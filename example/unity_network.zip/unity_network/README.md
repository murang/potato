# Unity 网络示例

将 `Network/` 和按需修改的 `Useage.cs` 放入 Unity 工程，沿用工程已有的 UniTask、Google.Protobuf、UnityWebSocket 和 `Log` 实现。`pb/` 保留协议与生成工具；其中 `pb/cs/` 和 `Network/Pb/` 是相同的生成代码，不要同时导入 Assets。

包格式保持不变：4 字节大端包体长度，后跟不超过 1 MiB 的包体。TCP/KCP 收包会在分配包体前拒绝负长度和超长包；读取中遇到 EOF 会报错并断开。

TCP/KCP 的 `Conn.Send` 保留 `void` 接口，在调用方编码后将完整帧加入同一个发送队列，由单个 writer 按入队顺序写出。排队和正在写入的帧合计最多 128 条、8 MiB，包含长度头；超出任一额度会触发 `OnException` 并断开，不能假定发送一定被接受。WebSocket 示例仍使用 UnityWebSocket 自身的发送机制。

`ConnOption.Timeout` 分别限制读取一个完整包、writer 写出当前帧的时间，不包括帧在队列中的等待时间。非正值使用 30 秒，`ConnectTimeout` 非正值使用 5 秒。超时及 `Disconnect` 会取消操作并关闭底层流，避免结束等待后旧写入仍继续执行。关闭不保证队列数据或已写数据送达对端；KCP 写入完成也不等于收到对端确认。

KCP 的异步读写在暂无数据或窗口满时，以 10 ms 周期可取消地等待，同时推进 UDP 输入、ACK 和 KCP Update，不在等待时持有 KCP 锁。低层 `KCPStream.Send` 返回本次实际接纳的字节数，可能为部分长度或 0；普通调用方应使用会处理剩余字节的 `WriteAsync`。同步 `Read/Write` 会阻塞调用线程，不适合 Unity 主线程。

连接生命周期操作应从 Unity 主线程发起；此示例不保证多线程并发 `Connect/Disconnect` 的事件顺序。并行收发时，超时关闭流可能先让另一方向报告 `IOException`，不能只依靠 `TimeoutException` 类型判断连接是否失效。

容量代价：每个 KCPStream 增加约 64 KiB 的 UDP 输入缓冲；上述 8 MiB 只限制 Conn 持有的帧，不包括编码临时分配、KCP 内部分片、UDP/socket 缓冲或整个进程内存。空闲接收会按 KCP 周期唤醒，发送窗口阻塞时还有发送侧检查；此示例没有做 Unity 设备上的容量或功耗压测。

本轮使用 .NET 8 外置检查运行了真实的这些源文件和 KCP 实现，覆盖 EOF、包长边界、分片读取、发送顺序、队列上限、超时清理及回环 UDP 上的 KCP 传输。检查中的 UniTask 调度适配使用了 stub，因此结果不替代 Unity/UniTask 实机、IL2CPP、平台网络权限及 WebSocket 验证。
